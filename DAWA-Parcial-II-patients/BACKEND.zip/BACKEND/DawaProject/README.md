
# Proyecto de Gestión de Terapias

Manejo de Web Services

## Comenzando 🚀

Estas instrucciones te permitirán obtener una copia del proyecto en funcionamiento en tu máquina local para propósitos de desarrollo y pruebas.

Mira *Deployment* para conocer como desplegar el proyecto.


### Pre-requisitos 📋

Tener instalado Python



### Instalación 🔧

Docker

## Despliegue 📦

Notas adicionales sobre como hacer deploy